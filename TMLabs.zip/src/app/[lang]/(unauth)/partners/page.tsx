export default function PartnersPage() {
	return <div>PartnersPage</div>
}
